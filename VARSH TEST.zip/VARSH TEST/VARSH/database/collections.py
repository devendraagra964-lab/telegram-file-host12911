from database.database import cursor, conn
from database.users import add_chi


# ------------------------
# Get Unique Collection Count
# ------------------------

def get_collection_count(user_id, series):

    cursor.execute("""
        SELECT COUNT(DISTINCT cards.id)

        FROM inventory

        JOIN cards

        ON inventory.card_id = cards.id

        WHERE inventory.telegram_id = ?

        AND cards.series = ?
    """, (
        user_id,
        series
    ))

    result = cursor.fetchone()

    return result[0] if result else 0



# ------------------------
# Get All Rewards Of Series
# ------------------------

def get_series_rewards(series):

    cursor.execute("""
        SELECT
            id,
            required_cards,
            reward_chi,
            reward_title

        FROM collection_rewards

        WHERE series = ?

        ORDER BY required_cards
    """, (
        series,
    ))

    return cursor.fetchall()



# ------------------------
# Get Available Rewards
# ------------------------

def get_available_rewards(user_id, series):

    count = get_collection_count(
        user_id,
        series
    )

    cursor.execute("""
        SELECT
            id,
            required_cards,
            reward_chi,
            reward_title

        FROM collection_rewards

        WHERE series = ?

        AND required_cards <= ?

        ORDER BY required_cards
    """, (
        series,
        count
    ))

    return cursor.fetchall()



# ------------------------
# Reward Claimed
# ------------------------

def reward_claimed(user_id, reward_id):

    cursor.execute("""
        SELECT id

        FROM claimed_rewards

        WHERE telegram_id = ?

        AND reward_id = ?
    """, (
        user_id,
        reward_id
    ))

    return cursor.fetchone() is not None



# ------------------------
# Get Claimed Rewards
# ------------------------

def get_claimed_rewards(user_id):

    cursor.execute("""
        SELECT reward_id

        FROM claimed_rewards

        WHERE telegram_id = ?
    """, (
        user_id,
    ))

    return [row[0] for row in cursor.fetchall()]



# ------------------------
# Claim Reward
# ------------------------

def claim_reward(user_id, reward_id, chi):

    cursor.execute("""
        INSERT INTO claimed_rewards
        (
            telegram_id,
            reward_id
        )

        VALUES (?, ?)
    """, (
        user_id,
        reward_id
    ))

    add_chi(
        user_id,
        chi
    )

    conn.commit()



# ------------------------
# Get Reward Status
# ------------------------

def get_reward_status(user_id, reward):

    reward_id = reward[0]

    if reward_claimed(
        user_id,
        reward_id
    ):
        return "CLAIMED"

    count = get_collection_count(
        user_id,
        get_reward_series(reward_id)
    )

    if count >= reward[1]:
        return "UNLOCKED"

    return "LOCKED"



# ------------------------
# Get Reward Series
# ------------------------

def get_reward_series(reward_id):

    cursor.execute("""
        SELECT series

        FROM collection_rewards

        WHERE id = ?
    """, (
        reward_id,
    ))

    result = cursor.fetchone()

    return result[0] if result else None