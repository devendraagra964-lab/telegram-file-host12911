from database.database import cursor, conn



def add_collection_reward(
    series,
    required_cards,
    reward_chi,
    title
):

    cursor.execute("""
        INSERT INTO collection_rewards
        (
            series,
            required_cards,
            reward_chi,
            reward_title
        )

        VALUES (?, ?, ?, ?)
    """, (
        series,
        required_cards,
        reward_chi,
        title
    ))


    conn.commit()



def get_rewards(series):

    cursor.execute("""
        SELECT
            id,
            required_cards,
            reward_chi,
            reward_title

        FROM collection_rewards

        WHERE series = ?

        ORDER BY required_cards
    """, (
        series,
    ))


    return cursor.fetchall()