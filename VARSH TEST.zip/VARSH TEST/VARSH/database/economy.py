from database.database import cursor, conn


def get_coins(telegram_id):
    cursor.execute(
        "SELECT coins FROM users WHERE telegram_id = ?",
        (telegram_id,)
    )

    result = cursor.fetchone()

    if result:
        return result[0]

    return 0


def add_coins(telegram_id, amount):
    cursor.execute(
        """
        UPDATE users
        SET coins = coins + ?
        WHERE telegram_id = ?
        """,
        (amount, telegram_id)
    )

    conn.commit()


def remove_coins(telegram_id, amount):
    cursor.execute(
        """
        UPDATE users
        SET coins = coins - ?
        WHERE telegram_id = ?
        """,
        (amount, telegram_id)
    )

    conn.commit()