import sqlite3


conn = sqlite3.connect("otaku_arena.db")

cursor = conn.cursor()


# =========================
# Migration Helper
# =========================

def add_column(table, column, datatype):

    try:

        cursor.execute(
            f"""
            ALTER TABLE {table}
            ADD COLUMN {column} {datatype}
            """
        )

        conn.commit()

        print(f"Migration added: {table}.{column}")

    except sqlite3.OperationalError:
        pass


# =========================
# CREATE TABLES
# =========================

def create_tables():

    # =========================
    # USERS
    # =========================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users(

        telegram_id INTEGER PRIMARY KEY,

        username TEXT NOT NULL,

        chi INTEGER DEFAULT 5000,

        total_rolls INTEGER DEFAULT 0,

        daily_rolls INTEGER DEFAULT 0,

        last_roll_reset TEXT,

        last_daily TEXT,

        join_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP

    )
    """)


    # =========================
    # CARDS
    # =========================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS cards(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        name TEXT NOT NULL,

        series TEXT NOT NULL,

        rarity TEXT NOT NULL,

        rating REAL NOT NULL,

        image_id TEXT NOT NULL,

        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP

    )
    """)


    # =========================
    # INVENTORY
    # =========================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS inventory(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        telegram_id INTEGER NOT NULL,

        card_id INTEGER NOT NULL,

        serial_number INTEGER UNIQUE,

        obtained_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP

    )
    """)


    # =========================
    # STORE
    # =========================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS store(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        item_type TEXT NOT NULL,

        item_id INTEGER NOT NULL,

        price INTEGER NOT NULL,

        expires_at TEXT NOT NULL

    )
    """)


    # =========================
    # DAILY STORE
    # =========================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS daily_store(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        card_id INTEGER NOT NULL,

        price INTEGER NOT NULL,

        expires_at TEXT NOT NULL

    )
    """)


    # =========================
    # MARKET
    # =========================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS market(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        seller_id INTEGER NOT NULL,

        card_id INTEGER NOT NULL,

        serial_number INTEGER UNIQUE,

        price INTEGER NOT NULL,

        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP

    )
    """)   

        # =========================
    # COLLECTION REWARDS
    # =========================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS collection_rewards(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        series TEXT NOT NULL,

        required_cards INTEGER NOT NULL,

        reward_chi INTEGER DEFAULT 0,

        reward_title TEXT NOT NULL

    )
    """)


    cursor.execute("""
    CREATE TABLE IF NOT EXISTS claimed_rewards(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        telegram_id INTEGER NOT NULL,

        reward_id INTEGER NOT NULL,

        UNIQUE(
            telegram_id,
            reward_id
        )

    )
    """)


    # =========================
    # BATTLE TEAM
    # =========================

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS battle_team(

        telegram_id INTEGER NOT NULL,

        slot INTEGER NOT NULL,

        serial_number INTEGER NOT NULL,

        PRIMARY KEY(
            telegram_id,
            slot
        )

    )
    """)


    # =========================
    # MIGRATIONS
    # =========================

    add_column(
        "users",
        "daily_rolls",
        "INTEGER DEFAULT 0"
    )

    add_column(
        "users",
        "last_roll_reset",
        "TEXT"
    )


    conn.commit()

    print("✅ Database Ready!")