import random
from datetime import datetime, timedelta

from database.database import cursor, conn


STORE_DURATION = 24


# ------------------------
# Clear Daily Store
# ------------------------

def clear_daily_store():

    cursor.execute(
        "DELETE FROM daily_store"
    )

    conn.commit()



# ------------------------
# Check Store
# ------------------------

def daily_store_exists():

    cursor.execute("""
        SELECT expires_at
        FROM daily_store
        LIMIT 1
    """)

    result = cursor.fetchone()


    if not result:
        return False


    expiry = datetime.fromisoformat(result[0])

    return datetime.now() < expiry



# ------------------------
# Generate Daily Cards
# ------------------------

def generate_daily_store():

    clear_daily_store()


    expiry_time = (
        datetime.now() + timedelta(hours=STORE_DURATION)
    ).isoformat()


    cursor.execute("""
        SELECT id, rarity
        FROM cards
        WHERE rarity NOT IN ('Mythic', 'Celestial')
    """)


    cards = cursor.fetchall()


    if not cards:
        return



    selected_cards = random.sample(
        cards,
        min(3, len(cards))
    )



    for card in selected_cards:

        card_id = card[0]
        rarity = card[1]


        # ------------------------
        # Rarity Pricing
        # ------------------------

        if rarity == "Common":

            price = 500


        elif rarity == "Rare":

            price = random.randint(
                2000,
                2500
            )


        elif rarity == "Epic":

            price = random.randint(
                4000,
                5000
            )


        elif rarity == "Legendary":

            price = random.randint(
                8000,
                10000
            )


        else:

            price = 0



        cursor.execute("""
            INSERT INTO daily_store
            (
                card_id,
                price,
                expires_at
            )
            VALUES (?, ?, ?)
        """, (
            card_id,
            price,
            expiry_time
        ))



    conn.commit()



# ------------------------
# Get Daily Store
# ------------------------

def get_daily_store():

    cursor.execute("""
        SELECT
            daily_store.id,
            cards.name,
            cards.series,
            cards.rarity,
            daily_store.price,
            daily_store.expires_at

        FROM daily_store

        JOIN cards
        ON daily_store.card_id = cards.id
    """)


    return cursor.fetchall()