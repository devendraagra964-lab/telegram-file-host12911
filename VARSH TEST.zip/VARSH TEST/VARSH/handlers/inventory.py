from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder

import sqlite3
from collections import defaultdict


router = Router()


# =========================
# RARITY ICONS
# =========================

RARITY_ICONS = {
    "Mythic": "🔴",
    "Legendary": "🟡",
    "Epic": "🟣",
    "Rare": "🔵",
    "Common": "⚪",
    "Celestial": "🌌"
}


# =========================
# GET COLLECTION
# =========================

def get_collection(user_id):

    conn = sqlite3.connect("otaku_arena.db")
    cursor = conn.cursor()

    cursor.execute(
        """
        SELECT
            cards.name,
            cards.series,
            cards.rarity
        FROM inventory
        JOIN cards
        ON inventory.card_id = cards.id
        WHERE inventory.telegram_id = ?
        """,
        (user_id,)
    )

    data = cursor.fetchall()

    conn.close()

    collection = defaultdict(lambda: defaultdict(lambda: {
        "count": 0,
        "rarity": ""
    }))

    for name, series, rarity in data:

        collection[series][name]["count"] += 1
        collection[series][name]["rarity"] = rarity

    return collection


# =========================
# GET BEST CARD IMAGE
# =========================

def get_best_card_image(user_id):

    conn = sqlite3.connect("otaku_arena.db")
    cursor = conn.cursor()

    cursor.execute(
        """
        SELECT
            cards.image_id
        FROM inventory
        JOIN cards
        ON inventory.card_id = cards.id
        WHERE inventory.telegram_id = ?
        ORDER BY cards.rating DESC
        LIMIT 1
        """,
        (user_id,)
    )

    card = cursor.fetchone()

    conn.close()

    if card:
        return card[0]

    return None


# =========================
# SERIES PAGES
# =========================

def get_series_pages(collection):

    pages = []

    for series in sorted(collection.keys()):

        text = f"📺 <b>{series}</b>\n"
        text += "━━━━━━━━━━━━━━\n\n"

        for name in sorted(collection[series].keys()):

            info = collection[series][name]

            icon = RARITY_ICONS.get(
                info["rarity"],
                "🎴"
            )

            count = info["count"]

            if count > 1:
                text += f"{icon} {name} ×{count}\n"
            else:
                text += f"{icon} {name}\n"

        pages.append(text)

    return pages


# =========================
# BUTTONS
# =========================

def inventory_buttons(page, total):

    keyboard = InlineKeyboardBuilder()

    if page > 0:
        keyboard.button(
            text="⬅️ Previous",
            callback_data=f"series_page_{page-1}"
        )

    if page < total - 1:
        keyboard.button(
            text="Next ➡️",
            callback_data=f"series_page_{page+1}"
        )

    keyboard.adjust(2)

    return keyboard.as_markup()


# =========================
# INVENTORY COMMAND
# =========================

@router.message(Command("inventory"))
async def inventory_command(message: Message):

    collection = get_collection(
        message.from_user.id
    )

    if not collection:

        await message.reply(
            "🎒 <b>Your collection is empty.</b>\n\n"
            "Roll cards using <code>/roll</code> to start collecting!",
            parse_mode="HTML"
        )

        return


    pages = get_series_pages(collection)

    best_image = get_best_card_image(
        message.from_user.id
    )


    # SEND BEST CARD IMAGE
    if best_image:

        await message.reply_photo(
            photo=best_image,
            caption="🏆 <b>BEST CARD</b>",
            parse_mode="HTML"
        )


    # SEND INVENTORY TEXT

    await message.reply(
        f"""
🎒 <b>{message.from_user.first_name}'s Inventory</b>

📚 <b>COLLECTION</b>

{pages[0]}

📖 <b>Series 1/{len(pages)}</b>
""",
        parse_mode="HTML",
        reply_markup=inventory_buttons(
            0,
            len(pages)
        )
    )


# =========================
# PAGE NAVIGATION
# =========================

@router.callback_query(lambda c: c.data.startswith("series_page_"))
async def series_navigation(callback: CallbackQuery):

    page = int(
        callback.data.split("_")[2]
    )

    collection = get_collection(
        callback.from_user.id
    )

    pages = get_series_pages(collection)


    await callback.message.edit_text(
        f"""
🎒 <b>{callback.from_user.first_name}'s Inventory</b>

📚 <b>COLLECTION</b>

{pages[page]}

📖 <b>Series {page+1}/{len(pages)}</b>
""",
        parse_mode="HTML",
        reply_markup=inventory_buttons(
            page,
            len(pages)
        )
    )

    await callback.answer()