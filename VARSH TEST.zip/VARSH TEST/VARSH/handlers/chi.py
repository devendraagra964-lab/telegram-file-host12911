from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from database.users import get_chi

router = Router()


@router.message(Command("chi"))
async def chi_command(message: Message):

    telegram_id = message.from_user.id

    chi = get_chi(telegram_id)

    await message.reply(
        "🌀 <b>Chi Wallet</b>\n"
        "━━━━━━━━━━━━━━\n\n"
        f"💠 <b>Current Balance:</b> {chi:,} Chi",
        parse_mode="HTML"
    )