from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

import sqlite3


router = Router()


# =========================
# /FLEX
# =========================

@router.message(Command("flex"))
async def flex_command(message: Message):

    parts = message.text.split(maxsplit=1)


    if len(parts) < 2:

        await message.reply(
            "❌ Use:\n"
            "/flex <card name>"
        )

        return



    card_name = parts[1]

    user_id = message.from_user.id



    conn = sqlite3.connect(
        "otaku_arena.db"
    )

    cursor = conn.cursor()



    # Check owned card

    cursor.execute(
        """
        SELECT
            cards.name,
            cards.series,
            cards.rarity,
            cards.rating,
            cards.image_id,
            inventory.serial_number

        FROM inventory

        JOIN cards

        ON inventory.card_id = cards.id

        WHERE inventory.telegram_id = ?

        AND LOWER(cards.name) = LOWER(?)

        LIMIT 1
        """,
        (
            user_id,
            card_name
        )
    )


    card = cursor.fetchone()


    conn.close()



    if not card:

        await message.reply(
            "❌ You don't own this card.\n\n"
            "🎲 Roll cards or trade to collect it!"
        )

        return



    name = card[0]
    series = card[1]
    rarity = card[2]
    rating = card[3]
    image = card[4]
    serial = card[5]



    await message.reply_photo(

        photo=image,

        caption=(
            "🔥 <b>CARD FLEX</b> 🔥\n\n"

            f"👤 <b>{message.from_user.first_name}</b> is flexing:\n\n"

            f"🎴 <b>{name}</b>\n"
            f"📺 Series: {series}\n"
            f"⭐ Rarity: {rarity}\n"
            f"⚡ Rating: {rating}\n"
            f"🔢 Serial: #{serial:06d}\n\n"

            "✨ A legendary piece of the collection!"
        ),

        parse_mode="HTML"
    )