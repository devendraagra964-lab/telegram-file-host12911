from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.context import FSMContext

from database.database import cursor, conn

import random
import asyncio


router = Router()


# =========================
# STATES
# =========================

class DoubleGame(StatesGroup):
    waiting_for_amount = State()


# =========================
# BUTTONS
# =========================

def double_button(amount):

    kb = InlineKeyboardBuilder()

    kb.button(
        text="🎲 Double or Nothing",
        callback_data=f"double_{amount}"
    )

    kb.adjust(1)

    return kb.as_markup()


# =========================
# /DOUBLE
# =========================

@router.message(Command("double"))
async def double_command(message: Message, state: FSMContext):

    cursor.execute(
        """
        SELECT chi
        FROM users
        WHERE telegram_id=?
        """,
        (message.from_user.id,)
    )

    user = cursor.fetchone()

    if not user:

        await message.reply(
            "❌ Register first using /start."
        )
        return

    await state.set_state(DoubleGame.waiting_for_amount)

    await message.reply(
        f"""
🎲 <b>DOUBLE OR NOTHING</b>

💰 Your Chi: <b>{user[0]}</b>

Send the amount of Chi you want to risk.
""",
        parse_mode="HTML"
    )


# =========================
# BET AMOUNT
# =========================

@router.message(DoubleGame.waiting_for_amount)
async def bet_amount(message: Message, state: FSMContext):

    if not message.text.isdigit():

        await message.reply(
            "❌ Enter a valid number."
        )
        return

    amount = int(message.text)

    if amount <= 0:

        await message.reply(
            "❌ Amount must be greater than 0."
        )
        return

    cursor.execute(
        """
        SELECT chi
        FROM users
        WHERE telegram_id=?
        """,
        (message.from_user.id,)
    )

    data = cursor.fetchone()

    if not data:

        await state.clear()

        await message.reply(
            "❌ Register first using /start."
        )

        return

    chi = data[0]

    if amount > chi:

        await message.reply(
            "❌ You don't have enough Chi."
        )

        return

    await state.clear()

    await message.reply(
        f"""
🎲 DOUBLE OR NOTHING

💰 Bet Amount:
{amount} Chi

⚠️ Win Chance: 40%
💀 Lose Chance: 60%

Press the button below to test your luck.
""",
        reply_markup=double_button(amount)
    )  

    # =========================
# DOUBLE GAME
# =========================

@router.callback_query(
    F.data.startswith("double_")
)
async def double_game(callback: CallbackQuery):

    amount = int(
        callback.data.split("_")[1]
    )

    user_id = callback.from_user.id

    # CHECK CURRENT CHI

    cursor.execute(
        """
        SELECT chi
        FROM users
        WHERE telegram_id=?
        """,
        (user_id,)
    )

    data = cursor.fetchone()

    if not data:

        await callback.answer(
            "User not found.",
            show_alert=True
        )

        return

    current_chi = data[0]

    if current_chi < amount:

        await callback.answer(
            "❌ You don't have enough Chi.",
            show_alert=True
        )

        return

    # REMOVE BUTTON

    await callback.message.edit_reply_markup(
        reply_markup=None
    )

    # ANIMATION

    await callback.message.edit_text(
        f"""
🎲 DOUBLE OR NOTHING

💰 Risking:
{amount} Chi

⚡ Charging Anime Energy...
"""
    )

    await asyncio.sleep(1)

    await callback.message.edit_text(
        f"""
🎲 DOUBLE OR NOTHING

💰 Risking:
{amount} Chi

✨ Destiny is deciding...
"""
    )

    await asyncio.sleep(1)

    await callback.message.edit_text(
        f"""
🎲 DOUBLE OR NOTHING

💰 Risking:
{amount} Chi

🌌 Rolling your fate...
"""
    )

    await asyncio.sleep(1.5)

    # RESULT

    roll = random.randint(1, 100)

    # =========================
    # WIN (40%)
    # =========================

    if roll <= 40:

        cursor.execute(
            """
            UPDATE users
            SET chi = chi + ?
            WHERE telegram_id=?
            """,
            (
                amount,
                user_id
            )
        )

        conn.commit()

        cursor.execute(
            """
            SELECT chi
            FROM users
            WHERE telegram_id=?
            """,
            (user_id,)
        )

        new_balance = cursor.fetchone()[0]

        await callback.message.edit_text(
            f"""
🌌 LEGENDARY LUCK!

🎉 YOU WON!

💰 Bet:
{amount} Chi

💎 Profit:
+{amount} Chi

🏦 New Balance:
{new_balance:,} Chi
"""
        )

    # =========================
    # LOSE (60%)
    # =========================

    else:

        cursor.execute(
            """
            UPDATE users
            SET chi = chi - ?
            WHERE telegram_id=?
            """,
            (
                amount,
                user_id
            )
        )

        conn.commit()

        cursor.execute(
            """
            SELECT chi
            FROM users
            WHERE telegram_id=?
            """,
            (user_id,)
        )

        new_balance = cursor.fetchone()[0]

        await callback.message.edit_text(
            f"""
💀 UNLUCKY FATE!

❌ YOU LOST!

💸 Lost:
{amount} Chi

🏦 New Balance:
{new_balance:,} Chi
"""
        )

    await callback.answer()