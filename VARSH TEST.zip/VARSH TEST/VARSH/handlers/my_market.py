from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder

from database.market import (
    get_user_market,
    remove_listing
)

from database.inventory import add_card


router = Router()


# ------------------------
# Buttons
# ------------------------

def my_market_buttons(listings):

    keyboard = InlineKeyboardBuilder()

    for listing in listings:

        listing_id = listing[0]
        name = listing[1]

        keyboard.button(
            text=f"❌ Remove {name}",
            callback_data=f"remove_listing_{listing_id}"
        )

    keyboard.adjust(1)

    return keyboard.as_markup()


# ------------------------
# My Market Command
# ------------------------

@router.message(Command("my_market"))
async def my_market_command(message: Message):

    listings = get_user_market(
        message.from_user.id
    )

    if not listings:

        await message.reply(
            "📜 Your market is empty.\n\n"
            "You have no cards listed."
        )

        return

    text = (
        "📜 <b>Your Market Listings</b>\n"
        "━━━━━━━━━━━━━━\n\n"
    )

    for index, card in enumerate(listings, start=1):

        text += (
            f"{index}. 🎴 <b>{card[1]}</b>\n"
            f"⭐ {card[2]}\n"
            f"🌀 Price: {card[3]:,} Chi\n"
            f"🔢 Serial: #{card[5]:06d}\n\n"
        )

    await message.reply(
        text,
        reply_markup=my_market_buttons(listings),
        parse_mode="HTML"
    )


# ------------------------
# Remove Listing
# ------------------------

@router.callback_query(
    lambda c: c.data.startswith("remove_listing_")
)
async def remove_market_listing(callback: CallbackQuery):

    listing_id = int(
        callback.data.split("_")[2]
    )

    listings = get_user_market(
        callback.from_user.id
    )

    selected = None

    for item in listings:

        if item[0] == listing_id:

            selected = item
            break

    if not selected:

        await callback.answer(
            "❌ Listing not found.",
            show_alert=True
        )

        return

    card_id = selected[4]

    # Return card to inventory

    serial = add_card(
        callback.from_user.id,
        card_id
    )

    remove_listing(
        listing_id
    )

    await callback.message.answer(
        "✅ Listing removed!\n\n"
        "🎴 Card returned to inventory.\n"
        f"🔢 New Serial: #{serial:06d}"
    )

    await callback.answer()