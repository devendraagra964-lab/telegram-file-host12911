from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup


from database.database import cursor, conn
from database.market import add_listing


router = Router()


class SellState(StatesGroup):

    waiting_price = State()



# ------------------------
# Get User Cards
# ------------------------

def get_user_cards(user_id):

    cursor.execute("""
        SELECT
            inventory.card_id,
            inventory.serial_number,
            cards.name,
            cards.series,
            cards.rarity

        FROM inventory

        JOIN cards

        ON inventory.card_id = cards.id

        WHERE inventory.telegram_id = ?
    """, (
        user_id,
    ))

    return cursor.fetchall()



# ------------------------
# Buttons
# ------------------------

def sell_buttons(cards):

    keyboard = InlineKeyboardBuilder()

    for card in cards:

        serial = card[1]
        name = card[2]

        keyboard.button(
            text=f"💰 Sell {name} #{serial:06d}",
            callback_data=f"sell_card_{serial}"
        )

    keyboard.adjust(1)

    return keyboard.as_markup()



# ------------------------
# Sell Command
# ------------------------

@router.message(Command("sell"))
async def sell_command(message: Message):

    cards = get_user_cards(
        message.from_user.id
    )


    if not cards:

        await message.reply(
            "🎴 You don't have any cards to sell."
        )

        return



    await message.reply(
        "💰 Select the card you want to sell:",
        reply_markup=sell_buttons(cards)
    )



# ------------------------
# Select Card
# ------------------------

@router.callback_query(
    lambda c: c.data.startswith("sell_card_")
)
async def select_sell_card(
    callback: CallbackQuery,
    state: FSMContext
):

    serial = int(
        callback.data.split("_")[2]
    )


    await state.update_data(
        serial=serial
    )


    await state.set_state(
        SellState.waiting_price
    )


    await callback.message.answer(
        "💰 Enter selling price in Chi:\n\n"
        "Example: 5000"
    )


    await callback.answer()



# ------------------------
# Receive Price
# ------------------------

@router.message(
    SellState.waiting_price
)
async def receive_price(
    message: Message,
    state: FSMContext
):

    if not message.text.isdigit():

        await message.reply(
            "❌ Enter numbers only."
        )

        return



    price = int(
        message.text
    )


    data = await state.get_data()

    serial = data["serial"]



    cursor.execute("""
        SELECT
            card_id

        FROM inventory

        WHERE telegram_id = ?
        AND serial_number = ?
    """, (
        message.from_user.id,
        serial
    ))


    card = cursor.fetchone()



    if not card:

        await message.reply(
            "❌ Card not found."
        )

        await state.clear()
        return



    card_id = card[0]



    # Add to market

    add_listing(
        message.from_user.id,
        card_id,
        serial,
        price
    )



    # Remove from inventory

    cursor.execute("""
        DELETE FROM inventory

        WHERE telegram_id = ?
        AND serial_number = ?
    """, (
        message.from_user.id,
        serial
    ))


    conn.commit()



    await message.reply(
        "✅ Card listed on Player Market!\n\n"
        f"🔢 Serial: #{serial:06d}\n"
        f"💰 Price: {price:,} Chi\n\n"
        "🎴 Card moved to Market storage."
    )


    await state.clear()