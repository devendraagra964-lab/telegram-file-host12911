from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

import sqlite3

router = Router()


@router.message(Command("card"))
async def card_command(message: Message):

    parts = message.text.split(maxsplit=1)

    if len(parts) < 2:
        await message.reply(
            "❌ Use: /card <character name>"
        )
        return


    name = parts[1]


    conn = sqlite3.connect("otaku_arena.db")
    cursor = conn.cursor()


    cursor.execute(
        """
        SELECT name, series, rarity, rating, image_id
        FROM cards
        WHERE LOWER(name)=LOWER(?)
        """,
        (name,)
    )


    card = cursor.fetchone()

    conn.close()


    if not card:
        await message.reply(
            "❌ Card not found!"
        )
        return


    await message.reply_photo(
        photo=card[4],
        caption=(
            f"🃏 {card[0]}\n"
            f"📺 Series: {card[1]}\n"
            f"⭐ Rarity: {card[2]}\n"
            f"⚡ Rating: {card[3]}"
        )
    )