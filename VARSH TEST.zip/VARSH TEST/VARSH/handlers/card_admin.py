from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

import sqlite3

from config import ADMIN_IDS


router = Router()


# Database connection
conn = sqlite3.connect("otaku_arena.db")
cursor = conn.cursor()



# =========================
# CARD CREATION STATES
# =========================

class CardCreate(StatesGroup):
    image = State()
    name = State()
    series = State()
    rarity = State()
    rating = State()



# =========================
# ADD CARD SYSTEM
# =========================

@router.message(Command("addcard"))
async def add_card(message: Message, state: FSMContext):

    if message.from_user.id not in ADMIN_IDS:
        await message.answer(
            "❌ You don't have permission to use this command."
        )
        return


    await message.answer(
        "🎴 Card Creator Started\n\n"
        "Send the card image."
    )


    await state.set_state(CardCreate.image)



# IMAGE

@router.message(CardCreate.image, F.photo)
async def get_image(message: Message, state: FSMContext):

    image_id = message.photo[-1].file_id


    await state.update_data(
        image_id=image_id
    )


    await message.answer(
        "✅ Image saved!\n\n"
        "Now send card name."
    )


    await state.set_state(CardCreate.name)



# NAME

@router.message(CardCreate.name)
async def get_name(message: Message, state: FSMContext):

    await state.update_data(
        name=message.text
    )


    await message.answer(
        "Send series name."
    )


    await state.set_state(CardCreate.series)



# SERIES

@router.message(CardCreate.series)
async def get_series(message: Message, state: FSMContext):

    await state.update_data(
        series=message.text
    )


    await message.answer(
        "Send rarity.\n\n"
        "Example:\n"
        "Mythic\n"
        "Legendary\n"
        "Epic\n"
        "Rare\n"
        "Common"
    )


    await state.set_state(CardCreate.rarity)



# RARITY

@router.message(CardCreate.rarity)
async def get_rarity(message: Message, state: FSMContext):

    await state.update_data(
        rarity=message.text
    )


    await message.answer(
        "Send rating.\n\n"
        "Example:\n"
        "9.8"
    )


    await state.set_state(CardCreate.rating)



# RATING + SAVE

@router.message(CardCreate.rating)
async def get_rating(message: Message, state: FSMContext):

    try:
        rating = float(message.text)

    except:

        await message.answer(
            "❌ Send rating as a number.\nExample: 9.8"
        )

        return



    data = await state.get_data()



    cursor.execute(
        """
        INSERT INTO cards
        (name, series, rarity, rating, image_id)
        VALUES (?, ?, ?, ?, ?)
        """,
        (
            data["name"],
            data["series"],
            data["rarity"],
            rating,
            data["image_id"]
        )
    )


    conn.commit()



    await message.answer(
        "✅ Card Added Successfully!\n\n"
        f"🎴 {data['name']}\n"
        f"📺 {data['series']}\n"
        f"⭐ {data['rarity']}\n"
        f"⚡ Rating: {rating}"
    )


    await state.clear()



# =========================
# VIEW ALL CARDS
# =========================

@router.message(Command("cards"))
async def show_cards(message: Message):

    if message.from_user.id not in ADMIN_IDS:

        await message.answer(
            "❌ You don't have permission to use this command."
        )

        return



    cursor.execute(
        """
        SELECT id, name, series, rarity, rating
        FROM cards
        ORDER BY id
        """
    )


    cards = cursor.fetchall()



    if not cards:

        await message.answer(
            "🎴 No cards found."
        )

        return



    text = "🎴 Otaku Arena Card Database\n\n"



    for card in cards:

        text += (
            f"🆔 ID: {card[0]}\n"
            f"🎴 {card[1]}\n"
            f"📺 {card[2]}\n"
            f"⭐ {card[3]}\n"
            f"⚡ Rating: {card[4]}\n\n"
        )



    await message.answer(text)