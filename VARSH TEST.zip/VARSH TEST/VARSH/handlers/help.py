from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

router = Router()


@router.message(Command("help"))
async def help_command(message: Message):

    await message.reply(
        """
🎴 <b>OTAKU ARENA</b>

Welcome to <b>Otaku Arena</b> — an anime & manga card collecting game where you build your collection, earn Chi, trade cards, and unlock rewards.

━━━━━━━━━━━━━━
👤 <b>PLAYER COMMANDS</b>
━━━━━━━━━━━━━━

🚀 <b>/start</b>
Create your account and enter the Arena.

❓ <b>/help</b>
View all commands and game information.

👤 <b>/profile</b>
View your player profile, Chi, rolls and collection stats.

🎲 <b>/roll</b>
Roll a random anime card.

• Cost: 1000 Chi
• Daily Limit: 5 Rolls

🖼 <b>/card &lt;name&gt;</b>
View details of any card.

Example:
<code>/card Son Goku</code>

🎒 <b>/inventory</b>
View all cards you own.

🎁 <b>/daily</b>
Claim your daily Chi reward.

💰 <b>/chi</b>
Check your Chi balance.

━━━━━━━━━━━━━━
🏪 <b>MARKET SYSTEM</b>
━━━━━━━━━━━━━━

🏪 <b>/store</b>
Buy cards from the Daily Store.

🛒 <b>/market</b>
Browse cards sold by players.

💸 <b>/sell</b>
List your cards for other players.

📦 <b>/my_market</b>
Manage your active listings.

━━━━━━━━━━━━━━
💎 <b>COLLECTIONS</b>
━━━━━━━━━━━━━━

💎 <b>/collections</b>
Check collection progress and unlock rewards.

Complete anime series collections to earn special rewards.

━━━━━━━━━━━━━━
🎰 <b>GAMES</b>
━━━━━━━━━━━━━━

🎰 <b>/double</b>
Play Double or Nothing.

Chance:
✨ 40% Win
💀 60% Lose

Win:
+Your bet

Lose:
-Your bet

━━━━━━━━━━━━━━
💰 <b>ABOUT CHI</b>
━━━━━━━━━━━━━━

Chi is the main currency of Otaku Arena.

Use Chi for:

• 🎲 Card Rolls
• 🏪 Store Purchases
• 🎰 Double or Nothing
• 🛒 Player Trading

Earn Chi from:

• 🎁 Daily Rewards
• 💰 Selling Cards
• 🏆 Collection Rewards
• Future Events

━━━━━━━━━━━━━━
🎴 <b>ABOUT CARDS</b>
━━━━━━━━━━━━━━

Collect anime characters and build your ultimate collection.

Card Rarities:

⚪ Common
🔵 Rare
🟣 Epic
🟡 Legendary
🔴 Mythic
✨ Celestial

Higher rarity cards are harder to obtain.

━━━━━━━━━━━━━━
🚧 <b>COMING SOON</b>
━━━━━━━━━━━━━━

⚔️ Advanced Game Modes
🏆 Leaderboards
🎉 Events
🎖 Achievements
✨ Special Card Abilities

More features coming to the Arena!

Good luck, Collector! 🍀
        """,
        parse_mode="HTML"
    )