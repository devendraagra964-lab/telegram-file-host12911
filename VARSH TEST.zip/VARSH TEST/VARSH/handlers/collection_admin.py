from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from database.collection_admin import add_collection_reward

from config import ADMIN_IDS


router = Router()



@router.message(Command("add_collection_reward"))
async def add_reward_command(message: Message):

    if message.from_user.id not in ADMIN_IDS:

        await message.reply(
            "❌ You are not allowed to use this command."
        )

        return



    try:

        data = message.text.split(maxsplit=4)


        if len(data) < 5:

            await message.reply(
                "❌ Format:\n\n"
                "/add_collection_reward "
                "Series Cards Chi Title\n\n"
                "Example:\n"
                "/add_collection_reward "
                "Jujutsu_Kaisen 15 10000 Beginner"
            )

            return



        series = data[1].replace("_", " ")

        required_cards = int(
            data[2]
        )

        reward_chi = int(
            data[3]
        )

        title = data[4]



        add_collection_reward(
            series,
            required_cards,
            reward_chi,
            title
        )



        await message.reply(
            "✅ Collection Reward Added!\n\n"
            f"📺 Series: {series}\n"
            f"🎴 Required Cards: {required_cards}\n"
            f"🌀 Reward: {reward_chi:,} Chi\n"
            f"👑 Title: {title}"
        )



    except Exception as e:

        await message.reply(
            f"❌ Error:\n{e}"
        )