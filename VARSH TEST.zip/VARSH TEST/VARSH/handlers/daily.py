from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from datetime import datetime, timedelta

from database.users import (
    add_chi,
    get_chi,
    get_last_daily,
    set_last_daily
)

router = Router()

DAILY_REWARD = 2000
COOLDOWN = timedelta(hours=24)


@router.message(Command("daily"))
async def daily_command(message: Message):

    telegram_id = message.from_user.id

    last_daily = get_last_daily(telegram_id)

    if last_daily:
        last_time = datetime.fromisoformat(last_daily)
        next_claim = last_time + COOLDOWN

        if datetime.now() < next_claim:
            remaining = next_claim - datetime.now()

            hours = remaining.seconds // 3600
            minutes = (remaining.seconds % 3600) // 60

            await message.reply(
                "⏳ You have already claimed your Daily Reward!\n\n"
                f"🕒 Come back in {hours}h {minutes}m."
            )
            return

    add_chi(telegram_id, DAILY_REWARD)
    set_last_daily(telegram_id)

    current_chi = get_chi(telegram_id)

    await message.reply(
        "🎁 Daily Reward Claimed!\n\n"
        f"🌀 +{DAILY_REWARD:,} Chi\n\n"
        f"🌀 Current Balance: {current_chi:,} Chi"
    )